import { useEffect, useState } from 'react'
import { supabase } from './lib/supabase'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import WorkOrders from './pages/WorkOrders'

function NavItem({ icon, label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-colors ${
        active ? 'text-cyan-400' : 'text-slate-500 hover:text-slate-300'
      }`}
    >
      <span className="text-xl leading-none">{icon}</span>
      <span className="text-xs font-semibold">{label}</span>
    </button>
  )
}

export default function App() {
  const [session, setSession] = useState(undefined) // undefined = loading
  const [profile, setProfile] = useState(null)
  const [company, setCompany] = useState(null)
  const [page, setPage] = useState('dashboard')
  const [profileLoading, setProfileLoading] = useState(false)

  // Auth listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
      if (!session) {
        setProfile(null)
        setCompany(null)
      }
    })
    return () => subscription.unsubscribe()
  }, [])

  // Fetch profile + company when session changes
  useEffect(() => {
    if (!session?.user) return

    const fetchProfileAndCompany = async () => {
      setProfileLoading(true)

      const { data: profileData } = await supabase
        .from('profiles')
        .select('id, company_id, role')
        .eq('id', session.user.id)
        .single()

      setProfile(profileData)

      if (profileData?.company_id) {
        const { data: companyData } = await supabase
          .from('companies')
          .select('id, name, phone')
          .eq('id', profileData.company_id)
          .single()
        setCompany(companyData)
      }

      setProfileLoading(false)
    }

    fetchProfileAndCompany()
  }, [session])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
  }

  // Loading screen
  if (session === undefined || (session && profileLoading)) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 text-sm">Loading…</p>
        </div>
      </div>
    )
  }

  // Unauthenticated
  if (!session) return <Login />

  // Authenticated shell
  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      {/* Top bar */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <span className="inline-block w-1.5 h-6 rounded-sm bg-cyan-400" />
          <span className="text-white font-black text-lg tracking-tight">FibrePro</span>
        </div>
        <button
          onClick={handleSignOut}
          className="text-slate-400 hover:text-white text-sm transition-colors flex items-center gap-1.5"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
          </svg>
          Sign out
        </button>
      </header>

      {/* Page content */}
      <main className="flex-1 px-4 py-6 max-w-2xl w-full mx-auto pb-28">
        {page === 'dashboard' && (
          <>
            <h1 className="text-white text-2xl font-bold mb-5">Dashboard</h1>
            <Dashboard profile={profile} company={company} />
          </>
        )}
        {page === 'workorders' && (
          <>
            <h1 className="text-white text-2xl font-bold mb-5">Work Orders</h1>
            <WorkOrders profile={profile} />
          </>
        )}
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 flex justify-around items-center py-1 z-10 safe-area-pb">
        <NavItem
          icon="⊞"
          label="Dashboard"
          active={page === 'dashboard'}
          onClick={() => setPage('dashboard')}
        />
        <NavItem
          icon="📋"
          label="Work Orders"
          active={page === 'workorders'}
          onClick={() => setPage('workorders')}
        />
      </nav>
    </div>
  )
}
