import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

function StatCard({ label, value, accent }) {
  const accentMap = {
    cyan: 'border-cyan-500 text-cyan-400',
    amber: 'border-amber-500 text-amber-400',
    emerald: 'border-emerald-500 text-emerald-400',
  }
  return (
    <div className={`bg-slate-900 border-l-4 ${accentMap[accent]} border-t border-r border-b border-slate-800 rounded-xl p-5`}>
      <p className="text-slate-400 text-xs font-semibold uppercase tracking-widest mb-2">{label}</p>
      <p className={`text-4xl font-black ${accentMap[accent].split(' ')[1]}`}>{value ?? '—'}</p>
    </div>
  )
}

export default function Dashboard({ profile, company }) {
  const [stats, setStats] = useState({ total: null, assigned: null, completed: null })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true)
      const isManager = profile?.role === 'manager'

      let totalQuery = supabase
        .from('work_orders')
        .select('id', { count: 'exact', head: true })
        .eq('company_id', profile.company_id)

      let assignedQuery = supabase
        .from('work_orders')
        .select('id', { count: 'exact', head: true })
        .eq('company_id', profile.company_id)

      let completedQuery = supabase
        .from('work_orders')
        .select('id', { count: 'exact', head: true })
        .eq('company_id', profile.company_id)
        .eq('status', 'completed')

      if (!isManager) {
        totalQuery = totalQuery.eq('technician_id', profile.id)
        assignedQuery = assignedQuery.eq('technician_id', profile.id)
        completedQuery = completedQuery.eq('technician_id', profile.id)
      }

      assignedQuery = assignedQuery.eq('status', 'assigned')

      const [totalRes, assignedRes, completedRes] = await Promise.all([
        totalQuery,
        assignedQuery,
        completedQuery,
      ])

      setStats({
        total: totalRes.count,
        assigned: assignedRes.count,
        completed: completedRes.count,
      })
      setLoading(false)
    }

    if (profile) fetchStats()
  }, [profile])

  const roleBadgeClass =
    profile?.role === 'manager'
      ? 'bg-amber-950 text-amber-300 border border-amber-800'
      : 'bg-cyan-950 text-cyan-300 border border-cyan-800'

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-slate-400 text-xs uppercase tracking-widest mb-1">Company</p>
            <h2 className="text-white text-xl font-bold">{company?.name ?? '—'}</h2>
            {company?.phone && (
              <p className="text-slate-500 text-sm mt-0.5">{company.phone}</p>
            )}
          </div>
          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold capitalize whitespace-nowrap ${roleBadgeClass}`}>
            {profile?.role ?? 'user'}
          </span>
        </div>
      </div>

      {/* Stats */}
      <div>
        <p className="text-slate-500 text-xs uppercase tracking-widest mb-3 px-0.5">Work Order Summary</p>
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-slate-900 border border-slate-800 rounded-xl p-5 animate-pulse h-24" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatCard label="Total" value={stats.total} accent="cyan" />
            <StatCard label="Assigned" value={stats.assigned} accent="amber" />
            <StatCard label="Completed" value={stats.completed} accent="emerald" />
          </div>
        )}
      </div>

      {/* Info note for role */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex gap-3 items-start">
        <span className="mt-0.5 text-cyan-400 text-lg leading-none">ℹ</span>
        <p className="text-slate-400 text-sm">
          {profile?.role === 'manager'
            ? 'As a manager, you have visibility into all work orders across your company.'
            : 'As a technician, your dashboard shows only the work orders assigned to you.'}
        </p>
      </div>
    </div>
  )
}
