import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const STATUS_STYLES = {
  assigned: 'bg-amber-950 text-amber-300 border-amber-800',
  in_progress: 'bg-blue-950 text-blue-300 border-blue-800',
  completed: 'bg-emerald-950 text-emerald-300 border-emerald-800',
  cancelled: 'bg-red-950 text-red-300 border-red-800',
}

function StatusBadge({ status }) {
  const style = STATUS_STYLES[status] ?? 'bg-slate-800 text-slate-300 border-slate-700'
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border capitalize ${style}`}>
      {status?.replace('_', ' ') ?? 'unknown'}
    </span>
  )
}

function WorkOrderCard({ order }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 hover:border-slate-700 transition-colors">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-slate-500 text-xs uppercase tracking-wider font-mono">#{order.order_number}</p>
          <h3 className="text-white font-semibold mt-0.5">{order.customer_name}</h3>
        </div>
        <StatusBadge status={order.status} />
      </div>

      <div className="space-y-1.5 text-sm">
        {order.customer_phone && (
          <div className="flex items-center gap-2 text-slate-400">
            <svg className="w-3.5 h-3.5 shrink-0 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
            </svg>
            <a href={`tel:${order.customer_phone}`} className="hover:text-cyan-400 transition-colors">
              {order.customer_phone}
            </a>
          </div>
        )}
        {order.address && (
          <div className="flex items-start gap-2 text-slate-400">
            <svg className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            <span>{order.address}</span>
          </div>
        )}
      </div>

      {order.created_at && (
        <p className="text-slate-600 text-xs pt-1 border-t border-slate-800">
          Created {new Date(order.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
        </p>
      )}
    </div>
  )
}

export default function WorkOrders({ profile }) {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  useEffect(() => {
    const fetchOrders = async () => {
      setLoading(true)
      setError(null)

      const isManager = profile?.role === 'manager'

      let query = supabase
        .from('work_orders')
        .select('id, order_number, customer_name, customer_phone, address, status, created_at')
        .eq('company_id', profile.company_id)
        .order('created_at', { ascending: false })

      if (!isManager) {
        query = query.eq('technician_id', profile.id)
      }

      const { data, error } = await query

      if (error) setError(error.message)
      else setOrders(data ?? [])
      setLoading(false)
    }

    if (profile) fetchOrders()
  }, [profile])

  const filtered = orders.filter((o) => {
    const matchSearch =
      !search ||
      o.customer_name?.toLowerCase().includes(search.toLowerCase()) ||
      o.order_number?.toLowerCase().includes(search.toLowerCase()) ||
      o.address?.toLowerCase().includes(search.toLowerCase())
    const matchStatus = statusFilter === 'all' || o.status === statusFilter
    return matchSearch && matchStatus
  })

  const statuses = ['all', 'assigned', 'in_progress', 'completed', 'cancelled']

  return (
    <div className="space-y-5">
      {/* Filters */}
      <div className="space-y-3">
        <input
          type="text"
          placeholder="Search by name, order number, or address…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 text-white placeholder-slate-500 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
        />

        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {statuses.map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors border ${
                statusFilter === s
                  ? 'bg-cyan-500 text-slate-950 border-cyan-500'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-600'
              }`}
            >
              {s.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {loading ? (
        <div className="space-y-4">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-slate-900 border border-slate-800 rounded-xl p-4 animate-pulse h-28" />
          ))}
        </div>
      ) : error ? (
        <div className="bg-red-950 border border-red-800 rounded-xl p-4 text-red-300 text-sm">{error}</div>
      ) : filtered.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center">
          <p className="text-slate-400 text-sm">No work orders match your filters.</p>
          <p className="text-slate-600 text-xs mt-1">Try adjusting your search or status filter.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-slate-500 text-xs uppercase tracking-widest">
            {filtered.length} {filtered.length === 1 ? 'order' : 'orders'}
          </p>
          {filtered.map((order) => (
            <WorkOrderCard key={order.id} order={order} />
          ))}
        </div>
      )}
    </div>
  )
}
