# FibrePro — Field Operations Platform

Mobile-first React + Vite + Tailwind app backed by Supabase.

## Quick Start

```bash
npm install
cp .env.example .env          # fill in your Supabase credentials
npm run dev
```

## Environment Variables

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

## Supabase Schema

Run this SQL in your Supabase SQL Editor:

```sql
-- Companies
create table companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text
);

-- Profiles (linked to auth.users)
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid references companies(id),
  role text not null default 'technician' check (role in ('technician', 'manager'))
);

-- Work Orders
create table work_orders (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id),
  technician_id uuid references profiles(id),
  order_number text not null,
  customer_name text,
  customer_phone text,
  address text,
  gps text,
  status text not null default 'assigned'
    check (status in ('assigned', 'in_progress', 'completed', 'cancelled')),
  start_time timestamptz,
  end_time timestamptz,
  created_at timestamptz default now()
);

-- Row Level Security
alter table profiles enable row level security;
alter table companies enable row level security;
alter table work_orders enable row level security;

-- Profiles: users can read their own profile
create policy "Own profile" on profiles
  for select using (auth.uid() = id);

-- Companies: users can read their own company
create policy "Own company" on companies
  for select using (
    id = (select company_id from profiles where id = auth.uid())
  );

-- Work orders: technicians see only assigned; managers see all
create policy "Technician work orders" on work_orders
  for select using (
    company_id = (select company_id from profiles where id = auth.uid())
    and (
      (select role from profiles where id = auth.uid()) = 'manager'
      or technician_id = auth.uid()
    )
  );

-- Auto-create profile on signup (optional trigger)
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();
```

## File Structure

```
src/
├── lib/
│   └── supabase.js       # Supabase client
├── pages/
│   ├── Login.jsx          # Email/password auth
│   ├── Dashboard.jsx      # Stats: total / assigned / completed
│   └── WorkOrders.jsx     # Filterable list, role-aware
├── App.jsx                # Shell: auth state, nav, routing
├── main.jsx
└── index.css
```

## Roles

| Role       | Dashboard         | Work Orders       |
|------------|-------------------|-------------------|
| technician | Own stats only    | Assigned to them  |
| manager    | Company-wide stats| All orders        |
